﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ShristiBroadcast.Models
{

    public class ExchangeDetail
    {
        public string Exchange { get; set; }
        public long Divider { get; set; }
        public int Value { get; set; }
    }




    public class ExchangeDetailsDto
        {
            [JsonPropertyName("exchanges")]
            public Dictionary<string, ExchangeInfoDto> Exchanges { get; set; }
        }

        public class ExchangeInfoDto
        {
            [JsonPropertyName("divider")]
            public long Divider { get; set; }

            [JsonPropertyName("value")]
            public int Value { get; set; }
        }


}
