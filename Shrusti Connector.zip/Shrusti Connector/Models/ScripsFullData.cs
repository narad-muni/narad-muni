﻿namespace ShristiBroadcast.Models
{
    public class ScripsFullData
    {
        public uint Token { get; set; }

        public long TotalBuyQty { get; set; }
        public long TotalSellQty { get; set; }
        public long Volume { get; set; }

        public ulong Ltt { get; set; }

        public uint Open { get; set; }
        public uint Close { get; set; }
        public uint High { get; set; }
        public uint Low { get; set; }
        public uint Ltp { get; set; }

        public ulong Ltq { get; set; }
        public uint Atp { get; set; }

        //public double NetChgPerc { get; set; }
        public int NetChgPerc { get; set; }
        public uint OpenInterest { get; set; }
        public double Turnover { get; set; }
        public int NetChgRaw { get; set; }

        public uint Upper { get; set; }
        public uint Lower { get; set; }
        public uint YearlyHigh { get; set; }
        public uint YearlyLow { get; set; }

        public uint MarketLot { get; set; }
        public byte Precision { get; set; }
        public uint Multiplier { get; set; }

        // Best Level 1
        public long BestBuyQty { get; set; }
        public int BestBuyPrice { get; set; }

        public long BestSellQty { get; set; }
        public int BestSellPrice { get; set; }

        public byte ExchangeId { get; set; }
    }
}
