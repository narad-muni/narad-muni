﻿using ShristiBroadcast.Models;

public interface IMarketDepth
{
    void OnMarketDepth(MarketDepthData data);
}