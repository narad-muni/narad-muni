﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShristiBroadcast.Models
{
    public class DepthLevel
    {
        public long Quantity { get; set; }
        public int Price { get; set; }
        public int Orders { get; set; }
    }
}
