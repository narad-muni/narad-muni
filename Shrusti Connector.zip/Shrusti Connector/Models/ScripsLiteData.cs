﻿namespace ShristiBroadcast.Models
{
    public class ScripsLiteData
    {
        public uint Token { get; set; }

        public ulong Ltt { get; set; }
        public uint Ltp { get; set; }
        public ulong Ltq { get; set; }

        public uint Close { get; set; }

        public int NetChgPerc { get; set; }
        public int NetChgRaw { get; set; }

        public uint MarketLot { get; set; }
        public byte Precision { get; set; }
        public uint Multiplier { get; set; }
    }
}
