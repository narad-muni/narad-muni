﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShristiBroadcast.Models
{
    public class TagMessageHeader
    {
        public ushort MessageLength { get; set; }
        public ushort MessageCode { get; set; }
        public byte Exchange { get; set; }
        public byte Level { get; set; }
        public byte AuctionStatus { get; set; }
        public byte SequenceNumber { get; set; }
        public byte BitmaskSize { get; set; }
    }
}
