﻿using ShristiBroadcast.Decoder;
using ShristiBroadcast.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace ShristiBroadcast.Client
{
    /// <summary>
    /// Stable thread-safe WebSocket client for Shristi broadcast feed.
    ///
    /// Fixes included compared to earlier version:
    /// 1. Thread-safe singleton GetInstance.
    /// 2. IConnection listener is NOT readonly; latest caller can refresh listener using SetListener.
    /// 3. ConnectAsync does NOT return immediately when connection is already in progress.
    ///    All callers await the same shared connection task.
    /// 4. SendJsonAsync checks WebSocket state before sending and serializes sends using SemaphoreSlim.
    /// 5. TLS 1.2 is enabled inside WebSocketClient itself.
    /// 6. Subscribe methods store symbols first, ensure connection, and avoid duplicate subscribe send when already registered.
    /// 7. ReceiveLoop handles fragmented binary messages safely.
    /// 8. Auto-resubscribe uses stored symbol registries after reconnect.
    /// </summary>
    public class WebSocketClient
    {
        private const string FeedUrl = "wss://cscast.kotaksecurities.com/wsfeed";

        private ClientWebSocket _socket;
        private readonly NativeBatchDecoder _decoder;

        // IMPORTANT: not readonly. Singleton should not keep first caller forever.
        private IConnection _listener;

        private CancellationTokenSource _cts;
        private readonly Random _rand = new Random();

        private volatile bool _shouldReconnect = true;
        private volatile bool _wasPreviouslyConnected = false;

        private readonly object _connectLock = new object();
        private Task _connectTask;

        private readonly SemaphoreSlim _sendLock = new SemaphoreSlim(1, 1);
        private readonly object _registryLock = new object();

        public bool IsConnected
        {
            get { return _socket != null && _socket.State == WebSocketState.Open; }
        }

        private static readonly object _instanceLock = new object();
        private static WebSocketClient _instance;

        public static WebSocketClient GetInstance(IConnection listener)
        {
            if (_instance != null)
            {
                _instance.SetListener(listener);
                return _instance;
            }

            lock (_instanceLock)
            {
                if (_instance == null)
                    _instance = new WebSocketClient(listener);

                _instance.SetListener(listener);
                return _instance;
            }
        }

        // ================================
        // SYMBOL REGISTRIES (AUTO RESUBSCRIBE)
        // ================================
        private readonly HashSet<string> _indicesSymbols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _depthSymbols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _scripLiteSymbols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _scripFullSymbols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // ================================
        // FEED LISTENER PROPERTIES
        // ================================
        public IIndexListener IndexListener
        {
            get { return _decoder.IndexListener; }
            set { _decoder.IndexListener = value; }
        }

        public IScripsLite ScripsLiteListener
        {
            get { return _decoder.ScripLiteListener; }
            set { _decoder.ScripLiteListener = value; }
        }

        public IScripsFull ScripsFullListener
        {
            get { return _decoder.ScripFullListener; }
            set { _decoder.ScripFullListener = value; }
        }

        public IMarketDepth MarketDepthListener
        {
            get { return _decoder.MarketDepthListener; }
            set { _decoder.MarketDepthListener = value; }
        }

        public WebSocketClient(IConnection listener)
        {
            EnableTls12();
            _listener = listener ?? throw new ArgumentNullException(nameof(listener));
            _decoder = new NativeBatchDecoder(listener);
            RefreshDecoderConnectionListener(listener);
            ApplyFeedListenersFromConnectionListener(listener);
        }

        /// <summary>
        /// Updates connection listener for singleton reuse.
        /// Call this whenever bridge obtains WebSocketClient.GetInstance(this).
        /// </summary>
        public void SetListener(IConnection listener)
        {
            if (listener == null) return;

            _listener = listener;
            RefreshDecoderConnectionListener(listener);
            ApplyFeedListenersFromConnectionListener(listener);
        }

        private static void EnableTls12()
        {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
        }

        private void ApplyFeedListenersFromConnectionListener(IConnection listener)
        {
            // If same listener also implements feed interfaces, wire them automatically.
            // BroadcastReceiverNew implements these interfaces, so this helps avoid missing callbacks.
            var indexListener = listener as IIndexListener;
            if (indexListener != null) IndexListener = indexListener;

            var liteListener = listener as IScripsLite;
            if (liteListener != null) ScripsLiteListener = liteListener;

            var fullListener = listener as IScripsFull;
            if (fullListener != null) ScripsFullListener = fullListener;

            var depthListener = listener as IMarketDepth;
            if (depthListener != null) MarketDepthListener = depthListener;
        }

        private void RefreshDecoderConnectionListener(IConnection listener)
        {
            // If NativeBatchDecoder internally keeps a private readonly listener, this tries to refresh it.
            // If the field does not exist, this safely does nothing.
            TrySetPrivateField(_decoder, "_listener", listener);
            TrySetPrivateField(_decoder, "listener", listener);
            TrySetPrivateField(_decoder, "_connectionListener", listener);
        }

        // ================================
        // CONNECT - STABLE SHARED TASK
        // ================================
        public Task ConnectAsync()
        {
            EnableTls12();
            _shouldReconnect = true;

            lock (_connectLock)
            {
                if (IsConnected)
                {
                    SafeText("Already connected.");
                    return Task.CompletedTask;
                }

                if (_connectTask != null && !_connectTask.IsCompleted)
                {
                    SafeText("Connection already in progress. Waiting for same connection task.");
                    return _connectTask;
                }

                _connectTask = ConnectCoreAsync();
                return _connectTask;
            }
        }

        private async Task ConnectCoreAsync()
        {
            try
            {
                while (_shouldReconnect && !IsConnected)
                {
                    try
                    {
                        EnableTls12();
                        DisposeSocketOnly();

                        _socket = new ClientWebSocket();
                        _cts = new CancellationTokenSource();

                        SafeText("Connecting to feed...");

                        await _socket.ConnectAsync(new Uri(FeedUrl), _cts.Token).ConfigureAwait(false);

                        if (IsConnected)
                        {
                            if (_wasPreviouslyConnected)
                                SafeReconnected("Reconnected successfully.");
                            else
                                SafeConnected("Connected successfully.");

                            _wasPreviouslyConnected = true;

                            await SendLoginAsync().ConfigureAwait(false);
                            await ResubscribeAllAsync().ConfigureAwait(false);

                            _ = Task.Run(() => ReceiveLoopAsync());
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        SafeError("Connect failed: " + ex.Message);
                    }

                    if (!_shouldReconnect || IsConnected)
                        break;

                    int delay = GetReconnectDelaySeconds();
                    SafeText("Reconnect in " + delay + " sec...");
                    await Task.Delay(TimeSpan.FromSeconds(delay)).ConfigureAwait(false);
                }
            }
            finally
            {
                lock (_connectLock)
                {
                    if (_connectTask != null && _connectTask.IsCompleted)
                        _connectTask = null;
                }
            }
        }

        public async Task<bool> WaitForConnectionAsync(int timeoutMs = 10000)
        {
            int delayMs = 250;
            int retries = Math.Max(1, timeoutMs / delayMs);

            for (int i = 0; i < retries; i++)
            {
                if (IsConnected) return true;
                await Task.Delay(delayMs).ConfigureAwait(false);
            }

            return IsConnected;
        }

        // ================================
        // RESUBSCRIBE ALL SYMBOLS
        // ================================
        private async Task ResubscribeAllAsync()
        {
            try
            {
                List<string> indices;
                List<string> depth;
                List<string> lite;
                List<string> full;

                lock (_registryLock)
                {
                    indices = new List<string>(_indicesSymbols);
                    depth = new List<string>(_depthSymbols);
                    lite = new List<string>(_scripLiteSymbols);
                    full = new List<string>(_scripFullSymbols);
                }

                foreach (string sym in indices)
                    await SubscribeIndicesAsync(sym, false).ConfigureAwait(false);

                foreach (string sym in depth)
                    await SubscribeMarketDepthAsync(sym, false).ConfigureAwait(false);

                foreach (string sym in lite)
                    await SubscribeScripLiteAsync(sym, false).ConfigureAwait(false);

                foreach (string sym in full)
                    await SubscribeScripsFullAsync(sym, false).ConfigureAwait(false);

                if (indices.Count > 0 || depth.Count > 0 || lite.Count > 0 || full.Count > 0)
                    SafeText("Auto re-subscription completed.");
            }
            catch (Exception ex)
            {
                SafeError("Resubscribe failed: " + ex.Message);
            }
        }

        // ================================
        // LOGIN
        // ================================
        private async Task SendLoginAsync()
        {
            var login = new
            {
                user = "1",
                auth = "1",
                format = "native_batch",
                source = "DTWeb"
            };

            await SendJsonAsync(login).ConfigureAwait(false);
        }

        // ================================
        // SUBSCRIBE INDICES
        // ================================
        public async Task SubscribeIndicesAsync(string symbol, bool store = true)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            bool newlyStored = true;
            if (store)
            {
                lock (_registryLock)
                    newlyStored = _indicesSymbols.Add(symbol);
            }

            await ConnectAsync().ConfigureAwait(false);

            if (store && !newlyStored && IsConnected)
            {
                SafeText("Indices already registered, duplicate send skipped: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "subscribeIndices",
                inputtoken = symbol,
                json = "false"
            }).ConfigureAwait(false);

            SafeText("Subscribed Indices: " + symbol);
        }

        public async Task UnsubscribeIndicesAsync(string symbol)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            lock (_registryLock)
                _indicesSymbols.Remove(symbol);

            if (!IsConnected)
            {
                SafeText("Socket not connected. Removed Indices registry only: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "unsubscribeIndices",
                inputtoken = symbol
            }).ConfigureAwait(false);

            SafeText("Unsubscribed Indices: " + symbol);
        }

        // ================================
        // SUBSCRIBE MARKET DEPTH
        // ================================
        public async Task SubscribeMarketDepthAsync(string symbol, bool store = true)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            bool newlyStored = true;
            if (store)
            {
                lock (_registryLock)
                    newlyStored = _depthSymbols.Add(symbol);
            }

            await ConnectAsync().ConfigureAwait(false);

            if (store && !newlyStored && IsConnected)
            {
                SafeText("MarketDepth already registered, duplicate send skipped: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "subscribeDepth",
                inputtoken = symbol,
                json = "false"
            }).ConfigureAwait(false);

            SafeText("Subscribed MarketDepth: " + symbol);
        }

        public async Task UnsubscribeMarketDepthAsync(string symbol)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            lock (_registryLock)
                _depthSymbols.Remove(symbol);

            if (!IsConnected)
            {
                SafeText("Socket not connected. Removed MarketDepth registry only: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "unsubscribeDepth",
                inputtoken = symbol
            }).ConfigureAwait(false);

            SafeText("Unsubscribed MarketDepth: " + symbol);
        }

        // ================================
        // SUBSCRIBE SCRIP LITE
        // ================================
        public async Task SubscribeScripLiteAsync(string symbol, bool store = true)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            bool newlyStored = true;
            if (store)
            {
                lock (_registryLock)
                    newlyStored = _scripLiteSymbols.Add(symbol);
            }

            await ConnectAsync().ConfigureAwait(false);

            if (store && !newlyStored && IsConnected)
            {
                SafeText("ScripLite already registered, duplicate send skipped: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "subscribeScripsLite",
                inputtoken = symbol,
                json = "false"
            }).ConfigureAwait(false);

            SafeText("Subscribed ScripLite: " + symbol);
        }

        public async Task UnsubscribeScripLiteAsync(string symbol)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            lock (_registryLock)
                _scripLiteSymbols.Remove(symbol);

            if (!IsConnected)
            {
                SafeText("Socket not connected. Removed ScripLite registry only: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "unsubscribeScripsLite",
                inputtoken = symbol
            }).ConfigureAwait(false);

            SafeText("Unsubscribed ScripLite: " + symbol);
        }

        // ================================
        // SUBSCRIBE FULL SCRIPS
        // ================================
        public async Task SubscribeScripsFullAsync(string symbol, bool store = true)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            bool newlyStored = true;
            if (store)
            {
                lock (_registryLock)
                    newlyStored = _scripFullSymbols.Add(symbol);
            }

            await ConnectAsync().ConfigureAwait(false);

            if (store && !newlyStored && IsConnected)
            {
                SafeText("ScripFull already registered, duplicate send skipped: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "subscribeScrips",
                inputtoken = symbol,
                json = "false"
            }).ConfigureAwait(false);

            SafeText("Subscribed ScripFull: " + symbol);
        }

        public async Task UnsubscribeScripsFullAsync(string symbol)
        {
            if (string.IsNullOrWhiteSpace(symbol)) return;

            lock (_registryLock)
                _scripFullSymbols.Remove(symbol);

            if (!IsConnected)
            {
                SafeText("Socket not connected. Removed ScripFull registry only: " + symbol);
                return;
            }

            await SendJsonAsync(new
            {
                @event = "unsubscribeScrips",
                inputtoken = symbol
            }).ConfigureAwait(false);

            SafeText("Unsubscribed ScripFull: " + symbol);
        }

        // ================================
        // SEND JSON
        // ================================
        private async Task SendJsonAsync(object obj)
        {
            if (obj == null) return;

            if (_socket == null)
                throw new InvalidOperationException("WebSocket is null.");

            if (_socket.State != WebSocketState.Open)
                throw new InvalidOperationException("WebSocket is not open. Current state: " + _socket.State);

            if (_cts == null || _cts.IsCancellationRequested)
                throw new InvalidOperationException("Cancellation token is not available or already cancelled.");

            string json = JsonSerializer.Serialize(obj);
            byte[] buffer = Encoding.UTF8.GetBytes(json);

            await _sendLock.WaitAsync().ConfigureAwait(false);
            try
            {
                if (_socket == null || _socket.State != WebSocketState.Open)
                    throw new InvalidOperationException("WebSocket became unavailable before send.");

                await _socket.SendAsync(
                    new ArraySegment<byte>(buffer),
                    WebSocketMessageType.Text,
                    true,
                    _cts.Token).ConfigureAwait(false);
            }
            finally
            {
                _sendLock.Release();
            }
        }

        // ================================
        // RECEIVE LOOP
        // ================================
        private async Task ReceiveLoopAsync()
        {
            ClientWebSocket currentSocket = _socket;
            CancellationTokenSource currentCts = _cts;

            byte[] buffer = new byte[32768];

            try
            {
                while (currentSocket != null &&
                       currentSocket.State == WebSocketState.Open &&
                       currentCts != null &&
                       !currentCts.IsCancellationRequested)
                {
                    using (var ms = new MemoryStream())
                    {
                        WebSocketReceiveResult result;

                        do
                        {
                            result = await currentSocket.ReceiveAsync(
                                new ArraySegment<byte>(buffer),
                                currentCts.Token).ConfigureAwait(false);

                            if (result.MessageType == WebSocketMessageType.Close)
                            {
                                SafeDisconnected("Socket close frame received.");
                                return;
                            }

                            if (result.Count > 0)
                                ms.Write(buffer, 0, result.Count);

                        } while (!result.EndOfMessage);

                        if (result.MessageType == WebSocketMessageType.Binary)
                        {
                            byte[] packet = ms.ToArray();
                            if (packet.Length > 0)
                                _decoder.ProcessBytes(packet);
                        }
                        else if (result.MessageType == WebSocketMessageType.Text)
                        {
                            string text = Encoding.UTF8.GetString(ms.ToArray());
                            SafeText(text);
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // Expected during DisconnectAsync.
            }
            catch (Exception ex)
            {
                SafeError("Receive loop error: " + ex.Message);
            }

            if (_shouldReconnect)
            {
                SafeDisconnected("Connection lost.");
                DisposeSocketOnly();

                int delay = GetReconnectDelaySeconds();
                SafeText("Connection lost. Reconnecting in " + delay + " sec...");
                await Task.Delay(TimeSpan.FromSeconds(delay)).ConfigureAwait(false);
                await ConnectAsync().ConfigureAwait(false);
            }
        }

        // ================================
        // DISCONNECT
        // ================================
        public async Task DisconnectAsync()
        {
            _shouldReconnect = false;

            try
            {
                if (_cts != null && !_cts.IsCancellationRequested)
                    _cts.Cancel();

                if (_socket != null && _socket.State == WebSocketState.Open)
                {
                    await _socket.CloseAsync(
                        WebSocketCloseStatus.NormalClosure,
                        "Closed by client",
                        CancellationToken.None).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                SafeError("Disconnect failed: " + ex.Message);
            }
            finally
            {
                DisposeSocketOnly();
                SafeDisconnected("Disconnected by client.");
            }
        }

        private void DisposeSocketOnly()
        {
            try { _socket?.Dispose(); } catch { }
            _socket = null;

            try { _cts?.Dispose(); } catch { }
            _cts = null;
        }

        private int GetReconnectDelaySeconds()
        {
            lock (_rand)
                return _rand.Next(5, 11);
        }

        // ================================
        // SAFE CALLBACKS
        // ================================
        private void SafeConnected(string message)
        {
            try { _listener?.OnConnected(message); } catch { }
        }

        private void SafeDisconnected(string message)
        {
            try { _listener?.OnDisconnected(message); } catch { }
        }

        private void SafeReconnected(string message)
        {
            try { _listener?.OnReconnected(message); } catch { }
        }

        private void SafeText(string message)
        {
            try { _listener?.OnTextMessage(message); } catch { }
        }

        private void SafeError(string message)
        {
            try { _listener?.OnError(message); } catch { }
        }

        private static void TrySetPrivateField(object target, string fieldName, object value)
        {
            try
            {
                if (target == null || string.IsNullOrWhiteSpace(fieldName) || value == null) return;

                FieldInfo field = target.GetType().GetField(
                    fieldName,
                    BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

                if (field != null && field.FieldType.IsInstanceOfType(value))
                    field.SetValue(target, value);
            }
            catch
            {
                // Safe fallback only. Ignore if field is not present or readonly.
            }
        }
    }
}
