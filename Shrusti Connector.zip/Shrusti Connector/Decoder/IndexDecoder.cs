﻿using ShristiBroadcast.Models;
using System;
using System.Diagnostics;
using System.Globalization;

namespace ShristiBroadcast.Decoder
{
    public static class IndexDecoder
    {
        public static IndexData Decode(byte[] bytes)
        {
            var data = new IndexData();
            int offset = 9; // Skip TagMessageHeader

            data.Token = BitConverter.ToUInt32(bytes, offset); offset += 4;

            data.Open = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Close = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.High = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Low = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Ltp = BitConverter.ToUInt32(bytes, offset); offset += 4;

            // Skip yearlyHigh + yearlyLow
            offset += 4; // yearlyHigh
            offset += 4; // yearlyLow

            data.NetChgRaw = BitConverter.ToInt32(bytes, offset); offset += 4;

            // Skip marketCap (float64)
            offset += 8;


            byte precision;
            uint multiplier;

            bool foundPrecision =
                IndexDecoder_Old.TryFindValidPrecisionAndMultiplier(
                    bytes,
                    offset,
                    out precision,
                    out multiplier);

            if (!foundPrecision)
            {
                precision = 2;
                multiplier = 1;
            }

            data.Precision = precision;
            data.Multiplier = multiplier;

            //data.Precision = bytes[offset++];
            //data.Multiplier = BitConverter.ToUInt32(bytes, offset);

            return data;
        }
    }


    public static class IndexDecoder_Old
    {
        private const int TagMessageHeaderSize = 9;

        /// <summary>
        /// Decode Shristi Index packet.
        /// Packet seen in debugger is byte[87].
        /// First 9 bytes are TagMessageHeader.
        /// From offset 9, OHLC/LTP fields are readable as UInt32 little-endian values.
        ///
        /// Important:
        /// In your packet, Precision was coming as 182, which is invalid.
        /// So this decoder validates precision and falls back to 2.
        /// </summary>
        public static IndexData Decode(byte[] bytes)
        {
            if (bytes == null)
                throw new ArgumentNullException(nameof(bytes));

            if (bytes.Length < TagMessageHeaderSize + 24)
                throw new ArgumentException("Invalid index packet length. Packet is too small.", nameof(bytes));

            var data = new IndexData();

            int offset = TagMessageHeaderSize;

            // --------------------------------------------------------------------
            // 1. Main index fields
            // --------------------------------------------------------------------
            // These offsets matched your sample packet:
            //
            // offset 9  : Token
            // offset 13 : Open
            // offset 17 : Close
            // offset 21 : High
            // offset 25 : Low
            // offset 29 : Ltp
            //
            // Raw values are like 2429797, 2429994 etc.
            // Final display price should generally be raw / 100.
            // --------------------------------------------------------------------

            data.Token = ReadUInt32(bytes, ref offset);
            data.Open = ReadUInt32(bytes, ref offset);
            data.Close = ReadUInt32(bytes, ref offset);
            data.High = ReadUInt32(bytes, ref offset);
            data.Low = ReadUInt32(bytes, ref offset);
            data.Ltp = ReadUInt32(bytes, ref offset);

            // --------------------------------------------------------------------
            // 2. Extra fields after LTP
            // --------------------------------------------------------------------
            // Your old decoder skipped yearlyHigh and yearlyLow.
            // Keep reading/skipping them safely.
            // If your IndexData model has YearlyHigh / YearlyLow, you can assign.
            // --------------------------------------------------------------------

            uint yearlyHigh = 0;
            uint yearlyLow = 0;

            if (CanRead(bytes, offset, 4))
                yearlyHigh = ReadUInt32(bytes, ref offset);

            if (CanRead(bytes, offset, 4))
                yearlyLow = ReadUInt32(bytes, ref offset);

            // --------------------------------------------------------------------
            // 3. Net change raw
            // --------------------------------------------------------------------

            if (CanRead(bytes, offset, 4))
                data.NetChgRaw = ReadInt32(bytes, ref offset);

            // --------------------------------------------------------------------
            // 4. Precision and Multiplier
            // --------------------------------------------------------------------
            // Problem in your old code:
            //
            // offset += 8;
            // data.Precision = bytes[offset++];
            // data.Multiplier = BitConverter.ToUInt32(bytes, offset);
            //
            // This produced:
            // Precision  = 182
            // Multiplier = 2800135395
            //
            // Precision 182 is invalid. So do NOT blindly trust that offset.
            // We scan remaining bytes for a valid precision/multiplier pair.
            // If not found, fallback to:
            // Precision = 2
            // Multiplier = 1
            // --------------------------------------------------------------------

            byte precision;
            uint multiplier;

            bool foundPrecision =
                TryFindValidPrecisionAndMultiplier(
                    bytes,
                    offset,
                    out precision,
                    out multiplier);

            if (!foundPrecision)
            {
                precision = 2;
                multiplier = 1;
            }

            data.Precision = precision;
            data.Multiplier = multiplier;

            // --------------------------------------------------------------------
            // Optional debug output. Keep during testing, remove later.
            // --------------------------------------------------------------------
            Debug.WriteLine("===== INDEX DECODE RESULT =====");
            Debug.WriteLine("Token      : " + data.Token);
            Debug.WriteLine("Open Raw   : " + data.Open + " => " + ToDisplayPrice(data.Open, data.Precision));
            Debug.WriteLine("Close Raw  : " + data.Close + " => " + ToDisplayPrice(data.Close, data.Precision));
            Debug.WriteLine("High Raw   : " + data.High + " => " + ToDisplayPrice(data.High, data.Precision));
            Debug.WriteLine("Low Raw    : " + data.Low + " => " + ToDisplayPrice(data.Low, data.Precision));
            Debug.WriteLine("Ltp Raw    : " + data.Ltp + " => " + ToDisplayPrice(data.Ltp, data.Precision));
            Debug.WriteLine("NetChgRaw  : " + data.NetChgRaw);
            Debug.WriteLine("Precision  : " + data.Precision);
            Debug.WriteLine("Multiplier : " + data.Multiplier);
            Debug.WriteLine("YearHigh   : " + yearlyHigh);
            Debug.WriteLine("YearLow    : " + yearlyLow);

            return data;
        }

        /// <summary>
        /// Converts raw index price to display price.
        /// Example:
        /// 2429994 with precision 2 = 24299.94
        /// </summary>
        public static decimal ToDisplayPrice(uint rawValue, byte precision)
        {
            if (precision > 6)
                precision = 2;

            decimal divider = (decimal)Math.Pow(10, precision);
            if (divider <= 0)
                divider = 100;

            return Math.Round(rawValue / divider, precision);
        }

        /// <summary>
        /// Converts raw net change to display change.
        /// </summary>
        public static decimal ToDisplayNetChange(int rawValue, byte precision)
        {
            if (precision > 6)
                precision = 2;

            decimal divider = (decimal)Math.Pow(10, precision);
            if (divider <= 0)
                divider = 100;

            return Math.Round(rawValue / divider, precision);
        }

        /// <summary>
        /// Use this method when converting IndexData to your Matrix MarketIndicesData.
        /// </summary>
        public static decimal GetIndexValue(IndexData data)
        {
            if (data == null) return 0;
            return ToDisplayPrice(data.Ltp, data.Precision);
        }

        public static decimal GetOpenPrice(IndexData data)
        {
            if (data == null) return 0;
            return ToDisplayPrice(data.Open, data.Precision);
        }

        public static decimal GetClosePrice(IndexData data)
        {
            if (data == null) return 0;
            return ToDisplayPrice(data.Close, data.Precision);
        }

        public static decimal GetHighPrice(IndexData data)
        {
            if (data == null) return 0;
            return ToDisplayPrice(data.High, data.Precision);
        }

        public static decimal GetLowPrice(IndexData data)
        {
            if (data == null) return 0;
            return ToDisplayPrice(data.Low, data.Precision);
        }

        public static decimal GetNetChange(IndexData data)
        {
            if (data == null) return 0;
            return ToDisplayNetChange(data.NetChgRaw, data.Precision);
        }

        // --------------------------------------------------------------------
        // Internal helper methods
        // --------------------------------------------------------------------

        private static uint ReadUInt32(byte[] bytes, ref int offset)
        {
            if (!CanRead(bytes, offset, 4))
                return 0;

            uint value = BitConverter.ToUInt32(bytes, offset);
            offset += 4;
            return value;
        }

        private static int ReadInt32(byte[] bytes, ref int offset)
        {
            if (!CanRead(bytes, offset, 4))
                return 0;

            int value = BitConverter.ToInt32(bytes, offset);
            offset += 4;
            return value;
        }

        private static bool CanRead(byte[] bytes, int offset, int size)
        {
            return bytes != null &&
                   offset >= 0 &&
                   size > 0 &&
                   offset + size <= bytes.Length;
        }

        /// <summary>
        /// Finds a sane precision and multiplier pair from remaining packet.
        ///
        /// Valid precision normally: 0 to 4, sometimes 6.
        /// Valid multiplier normally: 1, 10, 100, 1000, 10000.
        ///
        /// This avoids accepting wrong values like:
        /// Precision  = 182
        /// Multiplier = 2800135395
        /// </summary>
        public static bool TryFindValidPrecisionAndMultiplier(
            byte[] bytes,
            int searchStartOffset,
            out byte precision,
            out uint multiplier)
        {
            precision = 2;
            multiplier = 1;

            if (bytes == null || bytes.Length == 0)
                return false;

            int start = Math.Max(0, searchStartOffset);

            for (int i = start; i < bytes.Length; i++)
            {
                byte possiblePrecision = bytes[i];

                if (!IsValidPrecision(possiblePrecision))
                    continue;

                // Multiplier may be immediately after precision.
                if (CanRead(bytes, i + 1, 4))
                {
                    uint possibleMultiplier = BitConverter.ToUInt32(bytes, i + 1);

                    if (IsValidMultiplier(possibleMultiplier))
                    {
                        precision = possiblePrecision;
                        multiplier = possibleMultiplier;
                        return true;
                    }
                }

                // Some packets may not send multiplier properly.
                // If precision is valid and no multiplier is found, accept precision and default multiplier.
                if (possiblePrecision == 2)
                {
                    precision = possiblePrecision;
                    multiplier = 1;
                    return true;
                }
            }

            return false;
        }

        private static bool IsValidPrecision(byte precision)
        {
            return precision == 0 ||
                   precision == 1 ||
                   precision == 2 ||
                   precision == 3 ||
                   precision == 4 ||
                   precision == 6;
        }

        private static bool IsValidMultiplier(uint multiplier)
        {
            return multiplier == 1 ||
                   multiplier == 10 ||
                   multiplier == 100 ||
                   multiplier == 1000 ||
                   multiplier == 10000 ||
                   multiplier == 100000;
        }

        /// <summary>
        /// Useful for temporary debugging.
        /// Call DumpBytes(bytes) inside Decode if needed.
        /// </summary>
        public static string DumpBytes(byte[] bytes)
        {
            if (bytes == null)
                return string.Empty;

            return BitConverter.ToString(bytes);
        }

        /// <summary>
        /// Useful for printing readable byte positions.
        /// </summary>
        public static void DebugPrintBytes(byte[] bytes)
        {
            if (bytes == null)
                return;

            for (int i = 0; i < bytes.Length; i++)
            {
                Debug.WriteLine(
                    i.ToString(CultureInfo.InvariantCulture) +
                    " : " +
                    bytes[i].ToString(CultureInfo.InvariantCulture));
            }
        }
    }
}