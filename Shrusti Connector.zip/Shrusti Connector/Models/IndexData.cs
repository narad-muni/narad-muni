﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShristiBroadcast.Models
{
    public class IndexData
    {
        public uint Token { get; set; }

        public uint Open { get; set; }
        public uint Close { get; set; }
        public uint High { get; set; }
        public uint Low { get; set; }
        public uint Ltp { get; set; }

        public int NetChgRaw { get; set; }

        public byte Precision { get; set; }
        public uint Multiplier { get; set; }
    }
}
