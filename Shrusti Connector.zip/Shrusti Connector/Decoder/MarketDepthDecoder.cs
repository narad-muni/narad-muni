﻿using ShristiBroadcast.Models;
using System;

namespace ShristiBroadcast.Decoder
{
    public static class MarketDepthDecoder
    {
        public static MarketDepthData Decode(byte[] bytes)
        {
            var data = new MarketDepthData();
            int offset = 9; // Skip TagMessageHeader

            data.Token = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.TotalBuyQty = (ulong)BitConverter.ToInt64(bytes, offset); offset += 8;
            data.TotalSellQty = (ulong)BitConverter.ToInt64(bytes, offset); offset += 8;

            // Skip volume (int64)
            offset += 8;

            // Skip ltt (uint64)
            offset += 8;

            // Read LUT
            data.Lut = BitConverter.ToUInt64(bytes, offset); offset += 8;

            // Skip price fields
            offset += 4;  // open
            offset += 4;  // close
            offset += 4;  // high
            offset += 4;  // low
            offset += 4;  // ltp
            offset += 8;  // ltq
            offset += 4;  // atp
            offset += 4;  // indicativeClose

            // Depth counts
            data.BuyDepthCount = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.SellDepthCount = BitConverter.ToUInt32(bytes, offset); offset += 4;

            // Skip unused fields
            offset += 2;  // tradingStatus
            offset += 8;  // netChgPerc
            offset += 4;  // oi
            offset += 8;  // tradedValue
            offset += 4;  // netChg
            offset += 4;  // upper
            offset += 4;  // lower
            offset += 4;  // yearlyHigh
            offset += 4;  // yearlyLow

            // Market lot / precision / multiplier
            data.MarketLot = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Precision = bytes[offset++];
            data.Multiplier = BitConverter.ToUInt32(bytes, offset); offset += 4;

            // -------------------------
            // BUY DEPTH LEVELS
            // -------------------------
            for (int i = 0; i < data.BuyDepthCount; i++)
            {
                if (offset + 16 > bytes.Length) // 16 bytes total per level
                    break; // Stop if insufficient bytes remain
                try
                {


                    var level = new DepthLevel
                    {
                        Quantity = BitConverter.ToInt64(bytes, offset)
                    };
                    offset += 8;

                    level.Price = BitConverter.ToInt32(bytes, offset);
                    offset += 4;

                    level.Orders = BitConverter.ToInt32(bytes, offset);
                    offset += 4;

                    data.BuyLevels.Add(level);
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }

            // -------------------------
            // SELL DEPTH LEVELS
            // -------------------------
            for (int i = 0; i < data.SellDepthCount; i++)
            {
                if (offset + 16 > bytes.Length) // 16 bytes total per level
                    break; // Stop if insufficient bytes remain
                try
                {
                    var level = new DepthLevel
                    {
                        Quantity = BitConverter.ToInt64(bytes, offset)
                    };
                    offset += 8;

                    level.Price = BitConverter.ToInt32(bytes, offset);
                    offset += 4;

                    level.Orders = BitConverter.ToInt32(bytes, offset);
                    offset += 4;

                    data.SellLevels.Add(level);
                }
                catch (Exception ex)
                {

                    throw ex;
                }

            }

            return data;
        }
    }
}
