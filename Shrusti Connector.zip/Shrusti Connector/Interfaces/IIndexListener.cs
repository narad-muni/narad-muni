﻿using ShristiBroadcast.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShristiBroadcast.Interfaces
{
    public interface IIndexListener
    {
        void OnIndex(IndexData data);
    }
}
