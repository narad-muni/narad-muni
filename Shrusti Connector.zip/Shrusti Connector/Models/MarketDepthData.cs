﻿using System.Collections.Generic;

namespace ShristiBroadcast.Models
{
    //public class MarketDepthData_Old
    //{
    //    public uint Token { get; set; }

    //    public long TotalBuyQty { get; set; }
    //    public long TotalSellQty { get; set; }

    //    public ulong Lut { get; set; }

    //    public uint BuyDepthCount { get; set; }
    //    public uint SellDepthCount { get; set; }

    //    public uint MarketLot { get; set; }
    //    public byte Precision { get; set; }
    //    public uint Multiplier { get; set; }

    //    public List<DepthLevel> BuyLevels { get; set; } = new();
    //    public List<DepthLevel> SellLevels { get; set; } = new();
    //}
    public class MarketDepthData
    {
        public uint Token { get; set; }

        public ulong TotalBuyQty { get; set; }
        public ulong TotalSellQty { get; set; }
        public ulong volume_traded_today { get; set; }

        public ulong Ltt { get; set; }
        public ulong Lut { get; set; }

        public uint Open { get; set; }
        public uint Close { get; set; }
        public uint High { get; set; }
        public uint Low { get; set; }
        public uint Ltp { get; set; }

        public ulong Ltq { get; set; }
        public uint Atp { get; set; }
        public uint IndicativeClose { get; set; }

        public uint BuyDepthCount { get; set; }
        public uint SellDepthCount { get; set; }
        public short trading_status { get; set; }
        public int net_chg_percent { get; set; }

        public uint open_interest { get; set; }
        public double total_traded_value { get; set; }
        public short net_chg { get; set; }
        public uint upper_circuit { get; set; }
        public uint lower_circuit { get; set; }
        public uint yearly_high { get; set; }
        public uint yearly_low { get; set; }
        public uint MarketLot { get; set; }
        public ushort Precision { get; set; }
        public uint Multiplier { get; set; }
        public List<DepthLevel> BuyLevels { get; set; } = new List<DepthLevel>();
        public List<DepthLevel> SellLevels { get; set; } = new List<DepthLevel>();
    }
}
