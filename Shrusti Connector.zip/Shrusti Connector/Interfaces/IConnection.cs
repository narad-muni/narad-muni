﻿using ShristiBroadcast.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShristiBroadcast.Interfaces
{
    public interface IConnection
    {
        void OnConnected(string data);

        void OnDisconnected(string reason);

        void OnReconnected(string data);
        void OnLogin(List<ExchangeDetail> data);

        void OnTextMessage(string message);

        void OnError(string error);
    }
}
