﻿using ShristiBroadcast.Models;

public interface IScripsFull
{
    void OnScripsFull(ScripsFullData data);    
}