﻿using ShristiBroadcast.Interfaces;
using ShristiBroadcast.Models;
using System;
using System.IO;
using System.Collections.Generic;
using System.Text.Json;

namespace ShristiBroadcast.Decoder
{
    public class NativeBatchDecoder
    {
        private readonly IConnection _listener;

        // Listeners for different message types (level-based routing)
        public IScripsLite ScripLiteListener { get; set; }
        public IScripsFull ScripFullListener { get; set; }
        public IMarketDepth MarketDepthListener { get; set; }
        public IIndexListener IndexListener { get; set; }

        // Buffer used to merge partial packets across websocket frames
        private readonly MemoryStream _buffer = new MemoryStream();

        // Constructor injects connection listener for logging & error reporting
        public NativeBatchDecoder(IConnection listener)
        {
            _listener = listener;
        }

        // =========================================================
        // MAIN ENTRY: Process incoming binary websocket bytes
        // Handles:
        // - Partial packet merging
        // - Multi-packet batching
        // - Safe compaction after processing
        // =========================================================
        //public void ProcessBytes(byte[] incoming)
        //{
        //    try
        //    {
        //        // Append new incoming bytes to buffer tail
        //        _buffer.Position = _buffer.Length;
        //        _buffer.Write(incoming, 0, incoming.Length);

        //        // Start reading from beginning
        //        _buffer.Position = 0;

        //        while (true)
        //        {
        //            // Need minimum 2 bytes to read message length
        //            if (_buffer.Length - _buffer.Position < 2)
        //                break;

        //            long packetStart = _buffer.Position;

        //            ushort length = ReadUInt16(_buffer);

        //            // Validate length (avoid corrupt packets)
        //            if (length <= 0 || length > 65535)
        //            {
        //                _listener?.OnError($"Invalid packet length detected: {length}");
        //                break;
        //            }

        //            // If full packet not yet received, wait for next frame
        //            if (_buffer.Length - packetStart < length)
        //            {
        //                _buffer.Position = packetStart;
        //                break;
        //            }

        //            // Reset to start and read full packet
        //            _buffer.Position = packetStart;
        //            byte[] packet = new byte[length];
        //            _buffer.Read(packet, 0, length);

        //            DecodePacket(packet);
        //        }

        //        // Compact processed bytes (retain only incomplete tail)
        //        CompactBuffer();
        //    }
        //    catch (Exception ex)
        //    {
        //        _listener?.OnError("ProcessBytes error: " + ex.Message);
        //    }
        //}
        public void ProcessBytes(byte[] incoming)
        {
            try
            {
                // Append new bytes
                _buffer.Position = _buffer.Length;
                _buffer.Write(incoming, 0, incoming.Length);

                _buffer.Position = 0;

                while (true)
                {
                    // Need 2 bytes for length
                    if (_buffer.Length - _buffer.Position < 2)
                        break;

                    long packetStart = _buffer.Position;

                    // 🔥 Peek length WITHOUT advancing stream
                    ushort length = PeekUInt16(_buffer);

                    // Wait if full packet not available
                    if (_buffer.Length - packetStart < length)
                        break;

                    // Now advance pointer safely
                    _buffer.Position = packetStart + 2;

                    byte[] packet = new byte[length];
                    _buffer.Position = packetStart;
                    _buffer.Read(packet, 0, length);

                    DecodePacket(packet);
                }

                CompactBuffer();
            }
            catch (Exception ex)
            {
                _listener?.OnError("ProcessBytes error: " + ex.Message);
            }
        }

        private ushort PeekUInt16(Stream s)
        {
            long pos = s.Position;

            int b1 = s.ReadByte();
            int b2 = s.ReadByte();

            s.Position = pos; // restore position

            return (ushort)(b1 | (b2 << 8));
        }



        // =========================================================
        // Remove already processed bytes to avoid reprocessing
        // =========================================================
        private void CompactBuffer()
        {
            long remaining = _buffer.Length - _buffer.Position;

            if (remaining > 0)
            {
                byte[] leftover = new byte[remaining];
                _buffer.Read(leftover, 0, (int)remaining);

                _buffer.SetLength(0);
                _buffer.Write(leftover, 0, leftover.Length);
            }
            else
            {
                _buffer.SetLength(0);
            }

            // Move position to end for next append
            _buffer.Position = _buffer.Length;
        }

        // =========================================================
        // Decode a single native_batch packet
        // Routing based on messageCode and level
        // =========================================================
        private void DecodePacket(byte[] packet)
        {
            try
            {
                // Basic packet sanity check
                if (packet == null || packet.Length < 6)
                {
                    _listener?.OnError("Invalid packet received (too small).");
                    return;
                }

                // messageCode identifies broadcast type
                ushort messageCode = BitConverter.ToUInt16(packet, 2);

                // 7208 => equity / lite / depth (level-based)
                if (messageCode == 7208)
                {
                    byte level = packet[5]; // level decides structure

                    switch (level)
                    {
                        case 1:
                            // Scrips Lite tick
                            ScripLiteListener?.OnScripsLite(
                                ScripsLiteDecoder.Decode(packet));
                            break;

                        case 4:
                            // Full Scrips tick
                            ScripFullListener?.OnScripsFull(
                                ScripsDecoder.Decode(packet));
                            break;

                        case 8:
                            // Market depth tick
                            MarketDepthListener?.OnMarketDepth(
                                MarketDepthDecoder.Decode(packet));
                            break;

                        default:
                            // Unknown level (log but do not treat as fatal error)
                            _listener?.OnTextMessage($"Unknown level received: {level}");
                            break;
                    }
                }
                // 7207 => Index broadcast
                else if (messageCode == 7207)
                {
                    IndexListener?.OnIndex(IndexDecoder.Decode(packet));
                }
                else
                {
                    // Unknown message code
                   // _listener?.OnTextMessage($"Unhandled MessageCode: {messageCode}");
                }
            }
            catch (Exception ex)
            {
                // Any decoding exception should not crash feed
                _listener?.OnError("DecodePacket error: " + ex.Message);
            }
        }

        // =========================================================
        // Read UInt16 in little-endian (feed format)
        // =========================================================
        private ushort ReadUInt16(Stream s)
        {
            int b1 = s.ReadByte();
            int b2 = s.ReadByte();
            return (ushort)(b1 | (b2 << 8));
        }

        // =========================================================
        // Parse login exchange details JSON response
        // =========================================================
        public List<ExchangeDetail> ParseExchangeDetails(string json)
        {
            var result = new List<ExchangeDetail>();

            try
            {
                var dto = JsonSerializer.Deserialize<ExchangeDetailsDto>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                if (dto?.Exchanges != null)
                {
                    foreach (var kv in dto.Exchanges)
                    {
                        result.Add(new ExchangeDetail
                        {
                            Exchange = kv.Key,
                            Divider = kv.Value.Divider,
                            Value = kv.Value.Value
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _listener?.OnError("ExchangeDetails parsing failed: " + ex.Message);
            }

            return result;
        }
    }
}
