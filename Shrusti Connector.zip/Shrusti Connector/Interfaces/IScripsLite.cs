﻿using ShristiBroadcast.Models;

public interface IScripsLite
{
    void OnScripsLite(ScripsLiteData data);
}