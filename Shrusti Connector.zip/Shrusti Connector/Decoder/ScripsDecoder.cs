﻿using ShristiBroadcast.Models;
using System;

namespace ShristiBroadcast.Decoder
{
    public static class ScripsDecoder
    {
        public static ScripsFullData Decode(byte[] bytes)
        {
            var data = new ScripsFullData();
            int offset = 9;

            data.ExchangeId = bytes[4];

            data.Token = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.TotalBuyQty = BitConverter.ToInt64(bytes, offset); offset += 8;
            data.TotalSellQty = BitConverter.ToInt64(bytes, offset); offset += 8;
            data.Volume = BitConverter.ToInt64(bytes, offset); offset += 8;

            data.Ltt = BitConverter.ToUInt64(bytes, offset); offset += 8;
            offset += 8; // skip LUT

            data.Open = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Close = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.High = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Low = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Ltp = BitConverter.ToUInt32(bytes, offset); offset += 4;

            data.Ltq = BitConverter.ToUInt64(bytes, offset); offset += 8;
            data.Atp = BitConverter.ToUInt32(bytes, offset); offset += 4;

            offset += 4 + 4 + 4 + 2; // skip unused fields

            data.NetChgPerc = BitConverter.ToInt32(bytes, offset); offset += 4;
            data.OpenInterest = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Turnover = BitConverter.ToDouble(bytes, offset); offset += 8;
            data.NetChgRaw = BitConverter.ToInt32(bytes, offset); offset += 4;

            data.Upper = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Lower = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.YearlyHigh = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.YearlyLow = BitConverter.ToUInt32(bytes, offset); offset += 4;

            data.MarketLot = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Precision = bytes[offset++];
            data.Multiplier = BitConverter.ToUInt32(bytes, offset); offset += 4;

            data.BestBuyQty = BitConverter.ToInt64(bytes, offset); offset += 8;
            data.BestBuyPrice = BitConverter.ToInt32(bytes, offset); offset += 4;
            offset += 4; // skip buyOrders

            data.BestSellQty = BitConverter.ToInt64(bytes, offset); offset += 8;
            data.BestSellPrice = BitConverter.ToInt32(bytes, offset);

            return data;
        }
    }
}
