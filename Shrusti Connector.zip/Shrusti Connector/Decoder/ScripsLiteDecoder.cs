﻿using ShristiBroadcast.Models;
using System;

namespace ShristiBroadcast.Decoder
{
    public static class ScripsLiteDecoder
    {
        public static ScripsLiteData Decode(byte[] bytes)
        {
            var data = new ScripsLiteData();
            int offset = 9;

            data.Token = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Ltt = BitConverter.ToUInt64(bytes, offset); offset += 8;
            data.Ltp = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Ltq = BitConverter.ToUInt64(bytes, offset); offset += 8;
            data.Close = BitConverter.ToUInt32(bytes, offset); offset += 4;

            data.NetChgPerc = BitConverter.ToInt32(bytes, offset); offset += 4;
            data.NetChgRaw = BitConverter.ToInt32(bytes, offset); offset += 4;

            data.MarketLot = BitConverter.ToUInt32(bytes, offset); offset += 4;
            data.Precision = bytes[offset++];
            data.Multiplier = BitConverter.ToUInt32(bytes, offset);

            return data;
        }
    }
}
