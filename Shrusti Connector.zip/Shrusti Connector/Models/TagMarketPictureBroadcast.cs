﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShristiBroadcast.Models
{
    using System.Collections.Generic;

    namespace ShristiBroadcast.Models
    {
        public class TagMarketPictureBroadcast
        {
            public TagMessageHeader Header { get; set; }

            public uint Token { get; set; }
            public long TotalBuyQty { get; set; }
            public long TotalSellQty { get; set; }

            public long Volume { get; set; }
            public ulong Ltt { get; set; }
            public ulong Lut { get; set; }

            public uint Open { get; set; }
            public uint Close { get; set; }
            public uint High { get; set; }
            public uint Low { get; set; }
            public uint Ltp { get; set; }

            public ulong Ltq { get; set; }
            public uint Atp { get; set; }
            public uint IndicativeClose { get; set; }

            public uint BuyDepthCount { get; set; }
            public uint SellDepthCount { get; set; }

            public short TradingStatus { get; set; }
            public double NetChgPerc { get; set; }

            public uint OpenInterest { get; set; }
            public double TradedValue { get; set; }
            public int NetChg { get; set; }

            public uint Upper { get; set; }
            public uint Lower { get; set; }
            public uint YearlyHigh { get; set; }
            public uint YearlyLow { get; set; }

            public uint MarketLot { get; set; }
            public byte Precision { get; set; }
            public uint Multiplier { get; set; }

            public List<DepthLevel> BuyLevels { get; set; } = new List<DepthLevel>();
            public List<DepthLevel> SellLevels { get; set; } = new List<DepthLevel>();
        }
    }

}
